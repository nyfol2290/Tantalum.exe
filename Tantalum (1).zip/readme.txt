████████╗ █████╗ ███╗   ██╗████████╗ █████╗ ██╗     ██╗   ██╗███╗   ███╗   ███████╗██╗  ██╗███████╗
╚══██╔══╝██╔══██╗████╗  ██║╚══██╔══╝██╔══██╗██║     ██║   ██║████╗ ████║   ██╔════╝╚██╗██╔╝██╔════╝
   ██║   ███████║██╔██╗ ██║   ██║   ███████║██║     ██║   ██║██╔████╔██║   █████╗   ╚███╔╝ █████╗  
   ██║   ██╔══██║██║╚██╗██║   ██║   ██╔══██║██║     ██║   ██║██║╚██╔╝██║   ██╔══╝   ██╔██╗ ██╔══╝  
   ██║   ██║  ██║██║ ╚████║   ██║   ██║  ██║███████╗╚██████╔╝██║ ╚═╝ ██║██╗███████╗██╔╝ ██╗███████╗
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝

Created by: Nyfol2290 & N17Pro3426

This is a GDI trojan made in C++ that will overwrite MBR, disable the utilities (Task Manager, Run
and Control Panel), spam the System32 programs, change the window text and resize the windows.
Run this malware only on a VM and we aren't responsible for any damages.